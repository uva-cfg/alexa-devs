// work.js
// handles any computations performed before database retrieval or response
