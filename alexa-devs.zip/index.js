// index.js
// Alexa Dev Team Fall 2017
// Code for Good @UVa

'use strict';

// load additional files/modules needed
const feature1 = require('./feature1/res.js');
const mealExchange = require('./mealExchange/res.js');
const mealHours = require('./mealHours/res.js');
const Alexa = require('alexa-sdk');
//var mySlot = this.event.request.intent.slots.SlotName.value;
// define constants
const HELP_MESSAGE = "Welcome to Cav Assistant. For information on my capabilities, ask me to tell you what I can do.";
const HELP_REPROMPT = "Hi there. Ask me to tell you a U.V.A. tradition or for the phone number of a place nearby.";
const STOP_MESSAGE = "Thanks for talking. Wah who wah.";
const APP_ID = 'amzn1.ask.skill.e7b4f881-c503-4c43-bc24-29c242ed0890';

// set up handler to direct intent to proper content
const handlers = {
    // LaunchRequest when user says 'Alexa, open Cav Assistant'
    'LaunchRequest': function () {
      this.emit(':ask', "Welcome to Cav Assistant. What can I do for you?");
      //TEST: this.emit('FeatureOneIntent');
    },
    'TheyNeedToEatIntent': function () {
      // delegate slot collection to Alexa
      var filledSlots = delegateSlotCollection.call(this);

      // access collected slot
      let slotVal = this.event.request.intent.slots.diningHall.value;
      console.log(slotVal);

      // construct response
      let speechOutput = mealExchange.sendResponse(slotVal);
      this.emit(':tell', speechOutput);
    },
    'HappyFoodTimesIntent': function () {
      // delegate slot collection to Alexa
      var filledSlots = delegateSlotCollection.call(this);

      // access collected slot
      let slotVal = this.event.request.intent.slots.diningHall.value;
      console.log(slotVal);

      // construct response
      let speechOutput = mealHours.sendResponse(slotVal);
      this.emit(':tell', speechOutput);
    },
    // Feature1Intent when user says 'Show feature one.'
    'FeatureOneIntent': function () {
      // delegate slot collection to Alexa
      var filledSlots = delegateSlotCollection.call(this);

      // access collected slot
      let slotVal = this.event.request.intent.slots.diningHall.value;
      console.log(slotVal);

      // construct response
      let speechOutput = feature1.sendResponse(slotVal);
      this.emit(':tell', speechOutput);
    },
    // HelpIntent when user says 'Help'
    'AMAZON.HelpIntent': function () {
      const speechOutput = HELP_MESSAGE;
      const reprompt = HELP_REPROMPT;
      this.emit(':ask', speechOutput, reprompt);
    },
    // CancelIntent when the user says 'cancel'
    'AMAZON.CancelIntent': function () {
      this.emit(':tell', STOP_MESSAGE);
    },
    // StopIntent when the user says 'no' or 'stop'
    'AMAZON.StopIntent': function () {
      this.emit(':tell', STOP_MESSAGE);
    }
};

function delegateSlotCollection(){
  console.log("in delegateSlotCollection");
  console.log("current dialogState: "+this.event.request.dialogState);
    if (this.event.request.dialogState === "STARTED") {
      console.log("in Beginning");
      var updatedIntent=this.event.request.intent;
      this.emit(":delegate", updatedIntent);
    } else if (this.event.request.dialogState !== "COMPLETED") {
      console.log("in not completed");
      // return a Dialog.Delegate directive with no updatedIntent property.
      this.emit(":delegate");
    } else {
      console.log("in completed");
      console.log("returning: "+ JSON.stringify(this.event.request.intent));
      // Dialog is now complete and all required slots should be filled,
      // so call your normal intent handler.
      return this.event.request.intent;
    }
}

// Give the handler object and it's functions to the lambda for
// execution
exports.handler = function(event, context, callback) {
    const alexa = Alexa.handler(event, context); // create alexa obj
    alexa.appId = APP_ID; // register app id
    alexa.registerHandlers(handlers); // register handlers
    alexa.execute(); // begin
};
