// res.js
// handles user input and response
module.exports = {
  sendResponse: function sendResponse(slotId) {
    console.log(this);
    //TEST: this.emit(':tell', 'Sorry, I don\'t have that functionality yet.');
    let theSlotID = slotId;
    return (theSlotID);
  }
}
